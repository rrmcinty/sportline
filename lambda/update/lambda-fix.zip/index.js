// src/s3.ts
import { S3Client, GetObjectCommand, PutObjectCommand } from "@aws-sdk/client-s3";
var s3Client = new S3Client({});
async function getJsonFromS3(bucket, key) {
  const command = new GetObjectCommand({ Bucket: bucket, Key: key });
  const response = await s3Client.send(command);
  const body = await response.Body?.transformToString();
  if (!body) {
    throw new Error(`Empty response from S3: ${key}`);
  }
  return JSON.parse(body);
}
async function putJsonToS3(bucket, key, data) {
  const command = new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: JSON.stringify(data, null, 2),
    ContentType: "application/json"
  });
  await s3Client.send(command);
}

// src/espn.ts
async function fetchGameOdds(sport, league, gameId) {
  const espnSport = getEspnSport(sport);
  const url = `https://sports.core.api.espn.com/v2/sports/${espnSport}/leagues/${league}/events/${gameId}/competitions/${gameId}/odds`;
  try {
    const response = await fetch(url);
    if (!response.ok) {
      console.log(
        `  Failed to fetch odds for game ${gameId}: ${response.status} ${response.statusText}`
      );
      return null;
    }
    const data = await response.json();
    if (!data.items || data.items.length === 0) {
      console.log(`  No odds items for game ${gameId}`);
      return null;
    }
    const odds = data.items[0];
    const homeOdds = odds.homeTeamOdds;
    const awayOdds = odds.awayTeamOdds;
    return {
      gameId,
      priceHome: homeOdds?.moneyLine ?? null,
      priceAway: awayOdds?.moneyLine ?? null,
      line: odds.spread ?? null,
      // Top-level spread is the line (e.g., -13.5)
      provider: odds.provider?.name || "consensus"
    };
  } catch (error) {
    console.error(`  Error fetching odds for game ${gameId}:`, error);
    return null;
  }
}
function getEspnSport(sport) {
  const mapping = {
    nba: "basketball",
    ncaam: "basketball",
    nhl: "hockey",
    nfl: "football",
    cfb: "football"
  };
  return mapping[sport] || sport;
}
function getLeague(sport) {
  const mapping = {
    nba: "nba",
    ncaam: "mens-college-basketball",
    nhl: "nhl",
    nfl: "nfl",
    cfb: "college-football"
  };
  return mapping[sport] || sport;
}
async function fetchOddsForGames(sport, gameIds) {
  const league = getLeague(sport);
  const oddsMap = /* @__PURE__ */ new Map();
  const batchSize = 10;
  for (let i = 0; i < gameIds.length; i += batchSize) {
    const batch = gameIds.slice(i, i + batchSize);
    const promises = batch.map((gameId) => fetchGameOdds(sport, league, gameId));
    const results = await Promise.all(promises);
    for (const odds of results) {
      if (odds) {
        oddsMap.set(odds.gameId, odds);
      }
    }
  }
  return oddsMap;
}
async function fetchUpcomingGames(sport) {
  const espnSport = getEspnSport(sport);
  const league = getLeague(sport);
  const todayEST = (/* @__PURE__ */ new Date()).toLocaleDateString("en-US", { timeZone: "America/New_York" });
  const today = new Date(todayEST);
  const endDate = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1e3);
  const formatDate = (d) => `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
  const dates = `${formatDate(today)}-${formatDate(endDate)}`;
  let url = `https://site.api.espn.com/apis/site/v2/sports/${espnSport}/${league}/scoreboard?dates=${dates}`;
  try {
    let response = await fetch(url);
    if (!response.ok || response.status === 404) {
      console.log(`  Dates parameter not supported for ${sport}, trying without dates`);
      url = `https://site.api.espn.com/apis/site/v2/sports/${espnSport}/${league}/scoreboard`;
      response = await fetch(url);
      if (!response.ok) {
        console.error(`Failed to fetch scoreboard for ${sport}: ${response.status}`);
        return [];
      }
    }
    const data = await response.json();
    const events = data.events || [];
    if (events.length === 0 && url.includes("dates=")) {
      console.log(`  No events with dates parameter, trying without dates for ${sport}`);
      url = `https://site.api.espn.com/apis/site/v2/sports/${espnSport}/${league}/scoreboard`;
      response = await fetch(url);
      if (response.ok) {
        const fallbackData = await response.json();
        events.push(...fallbackData.events || []);
      }
    }
    const upcomingGames = [];
    for (const event of events) {
      const status = event.status?.type?.name;
      if (status !== "STATUS_SCHEDULED") {
        continue;
      }
      const competition = event.competitions?.[0];
      if (!competition)
        continue;
      const homeTeam = competition.competitors?.find((c) => c.homeAway === "home");
      const awayTeam = competition.competitors?.find((c) => c.homeAway === "away");
      if (!homeTeam || !awayTeam)
        continue;
      upcomingGames.push({
        id: event.id,
        sport,
        date: event.date,
        season: event.season?.year || (/* @__PURE__ */ new Date()).getFullYear(),
        homeTeamId: homeTeam.team.id,
        awayTeamId: awayTeam.team.id
      });
    }
    console.log(`  Found ${upcomingGames.length} upcoming ${sport.toUpperCase()} games`);
    return upcomingGames;
  } catch (error) {
    console.error(`Error fetching upcoming games for ${sport}:`, error);
    return [];
  }
}

// src/index.ts
var BUCKET = process.env.BUCKET || `sportline-data-${process.env.USER || "dev"}`;
var MIN_EDGE = 0.03;
var MAX_EV = 0.75;
function americanToImpliedProb(americanOdds) {
  if (americanOdds > 0) {
    return 100 / (americanOdds + 100);
  } else {
    return -americanOdds / (-americanOdds + 100);
  }
}
function calculateEV(probability, americanOdds) {
  const impliedProb = americanToImpliedProb(americanOdds);
  const decimalOdds = americanOdds > 0 ? americanOdds / 100 + 1 : 100 / -americanOdds + 1;
  return probability * decimalOdds - 1;
}
function passesJuiceGate(betOdds, betEdge) {
  const MAX_VIG_PRICE = -115;
  const EDGE_REQUIRED_IF_VIGGY = 0.04;
  if (betOdds <= MAX_VIG_PRICE && betEdge < EDGE_REQUIRED_IF_VIGGY)
    return false;
  return true;
}
function isInOptimalBucket(config, sport, market, probability) {
  const sportBuckets = config.optimalBuckets[sport];
  if (!sportBuckets)
    return false;
  const buckets = sportBuckets[market];
  const probPercent = probability * 100;
  return buckets.some((bucket) => probPercent >= bucket.min && probPercent <= bucket.max);
}
function enrichRecommendation(rec, teamsData, configData) {
  const sportTeams = teamsData[rec.sport] || {};
  const homeTeamName = sportTeams[rec.homeTeamId] || `Team ${rec.homeTeamId}`;
  const awayTeamName = sportTeams[rec.awayTeamId] || `Team ${rec.awayTeamId}`;
  const pickTeamName = rec.side === "home" ? homeTeamName : awayTeamName;
  const isBest = isInOptimalBucket(
    configData,
    rec.sport,
    rec.market,
    rec.modelProbability
  );
  return {
    ...rec,
    homeTeamName,
    awayTeamName,
    pickTeamName,
    isBest
  };
}
async function handler(event) {
  console.log("Update Lambda starting...", { event });
  const sports = ["nba", "ncaam", "nhl"];
  const allRecommendations = [];
  const teamsData = await getJsonFromS3(BUCKET, "features/teams.json");
  const configData = await getJsonFromS3(BUCKET, "features/config.json");
  for (const sport of sports) {
    try {
      console.log(`Processing ${sport}...`);
      const predictionsData = await getJsonFromS3(
        BUCKET,
        `features/${sport}-predictions.json`
      );
      console.log(`  Loaded ${Object.keys(predictionsData.predictions).length} predictions`);
      const allUpcomingGames = await fetchUpcomingGames(sport);
      const todayEST = (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA", { timeZone: "America/New_York" });
      console.log(`  DEBUG: Today in EST: ${todayEST}`);
      allUpcomingGames.slice(0, 3).forEach((g) => {
        const gDate = new Date(g.date);
        const gDateEST = gDate.toLocaleDateString("en-CA", { timeZone: "America/New_York" });
        console.log(`  DEBUG: Game ${g.id} - UTC: ${g.date}, EST: ${gDateEST}`);
      });
      const upcomingGames = allUpcomingGames.filter((game) => {
        const gameDate = new Date(game.date);
        const gameDateEST = gameDate.toLocaleDateString("en-CA", { timeZone: "America/New_York" });
        return gameDateEST === todayEST;
      });
      console.log(`  Found ${upcomingGames.length} upcoming games for today (${todayEST})`);
      if (upcomingGames.length === 0) {
        continue;
      }
      const gameIds = upcomingGames.map((g) => g.id);
      const oddsMap = await fetchOddsForGames(sport, gameIds);
      console.log(`  Fetched odds for ${oddsMap.size} games`);
      let gamesProcessed = 0;
      for (const game of upcomingGames) {
        const odds = oddsMap.get(game.id);
        if (!odds) {
          continue;
        }
        const prediction = predictionsData.predictions[game.id];
        if (!prediction) {
          console.warn(`  No prediction for game ${game.id} - run npm run sync`);
          continue;
        }
        const homeWinProb = prediction.moneyline;
        const spreadProb = prediction.spread;
        if (odds.priceHome !== null) {
          const homeImpliedProb = americanToImpliedProb(odds.priceHome);
          const edge = homeWinProb - homeImpliedProb;
          const ev = calculateEV(homeWinProb, odds.priceHome);
          if (gamesProcessed < 3) {
            console.log(
              `  DEBUG ${game.id}: Home=${game.homeTeamId} Away=${game.awayTeamId} Prob=${(homeWinProb * 100).toFixed(1)}% Implied=${(homeImpliedProb * 100).toFixed(1)}% Edge=${(edge * 100).toFixed(1)}%`
            );
          }
          gamesProcessed++;
          if (edge >= MIN_EDGE && ev <= MAX_EV && passesJuiceGate(odds.priceHome, edge)) {
            const baseRec = {
              gameId: game.id,
              gameDate: game.date,
              sport,
              homeTeamId: game.homeTeamId,
              awayTeamId: game.awayTeamId,
              market: "moneyline",
              side: "home",
              modelProbability: homeWinProb,
              impliedProbability: homeImpliedProb,
              odds: odds.priceHome,
              line: null,
              edge,
              ev,
              provider: odds.provider
            };
            allRecommendations.push(enrichRecommendation(baseRec, teamsData, configData));
          }
        }
        if (odds.priceAway !== null) {
          const awayWinProb = 1 - homeWinProb;
          const impliedProb = americanToImpliedProb(odds.priceAway);
          const edge = awayWinProb - impliedProb;
          const ev = calculateEV(awayWinProb, odds.priceAway);
          if (edge >= MIN_EDGE && ev <= MAX_EV && passesJuiceGate(odds.priceAway, edge)) {
            const baseRec = {
              gameId: game.id,
              gameDate: game.date,
              sport,
              homeTeamId: game.homeTeamId,
              awayTeamId: game.awayTeamId,
              market: "moneyline",
              side: "away",
              modelProbability: awayWinProb,
              impliedProbability: impliedProb,
              odds: odds.priceAway,
              line: null,
              edge,
              ev,
              provider: odds.provider
            };
            allRecommendations.push(enrichRecommendation(baseRec, teamsData, configData));
          }
        }
        if (odds.line !== null) {
          const homeCoversProb = spreadProb;
          const spreadOdds = -110;
          const impliedProb = americanToImpliedProb(spreadOdds);
          const edge = homeCoversProb - impliedProb;
          const ev = calculateEV(homeCoversProb, spreadOdds);
          if (edge >= MIN_EDGE && ev <= MAX_EV && passesJuiceGate(spreadOdds, edge)) {
            const baseRec = {
              gameId: game.id,
              gameDate: game.date,
              sport,
              homeTeamId: game.homeTeamId,
              awayTeamId: game.awayTeamId,
              market: "spread",
              side: homeCoversProb >= 0.5 ? "home" : "away",
              modelProbability: homeCoversProb >= 0.5 ? homeCoversProb : 1 - homeCoversProb,
              impliedProbability: impliedProb,
              odds: spreadOdds,
              line: odds.line,
              edge,
              ev,
              provider: odds.provider
            };
            allRecommendations.push(enrichRecommendation(baseRec, teamsData, configData));
          }
        }
      }
    } catch (error) {
      console.error(`Error processing ${sport}:`, error);
    }
  }
  allRecommendations.sort((a, b) => b.edge - a.edge);
  const output = {
    generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    recommendations: allRecommendations
  };
  await putJsonToS3(BUCKET, "daily/recs.json", output);
  console.log(`Update complete: ${allRecommendations.length} recommendations`);
  return {
    statusCode: 200,
    body: JSON.stringify({
      success: true,
      count: allRecommendations.length,
      generatedAt: output.generatedAt
    })
  };
}
export {
  handler
};
