// src/s3.ts
import { S3Client, GetObjectCommand, PutObjectCommand } from "@aws-sdk/client-s3";
var s3Client = new S3Client({});
async function getJsonFromS3(bucket, key) {
  const command = new GetObjectCommand({ Bucket: bucket, Key: key });
  const response = await s3Client.send(command);
  const body = await response.Body?.transformToString();
  if (!body) {
    throw new Error(`Empty response from S3: ${key}`);
  }
  return JSON.parse(body);
}
async function putJsonToS3(bucket, key, data) {
  const command = new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: JSON.stringify(data, null, 2),
    ContentType: "application/json"
  });
  await s3Client.send(command);
}

// src/espn.ts
async function fetchGameOdds(sport, league, gameId) {
  const url = `https://sports.core.api.espn.com/v2/sports/${sport}/leagues/${league}/events/${gameId}/competitions/${gameId}/odds`;
  try {
    const response = await fetch(url);
    if (!response.ok) {
      return null;
    }
    const data = await response.json();
    if (!data.items || data.items.length === 0) {
      return null;
    }
    const odds = data.items[0];
    const homeOdds = odds.homeTeamOdds;
    const awayOdds = odds.awayTeamOdds;
    return {
      gameId,
      priceHome: homeOdds?.moneyLine ?? null,
      priceAway: awayOdds?.moneyLine ?? null,
      line: homeOdds?.spreadOdds ?? null,
      provider: odds.provider?.name || "consensus"
    };
  } catch (_error) {
    return null;
  }
}
function getLeague(sport) {
  const mapping = {
    nba: "nba",
    ncaam: "mens-college-basketball",
    nhl: "nhl",
    nfl: "nfl",
    cfb: "college-football"
  };
  return mapping[sport] || sport;
}
async function fetchOddsForGames(sport, gameIds) {
  const league = getLeague(sport);
  const oddsMap = /* @__PURE__ */ new Map();
  const batchSize = 10;
  for (let i = 0; i < gameIds.length; i += batchSize) {
    const batch = gameIds.slice(i, i + batchSize);
    const promises = batch.map((gameId) => fetchGameOdds(sport, league, gameId));
    const results = await Promise.all(promises);
    for (const odds of results) {
      if (odds) {
        oddsMap.set(odds.gameId, odds);
      }
    }
  }
  return oddsMap;
}

// src/predict.ts
function buildFeatureVector(homeFeatures, awayFeatures, featureNames) {
  const features = [];
  for (const featureName of featureNames) {
    let value = 0;
    if (featureName.startsWith("home")) {
      const key = featureName.replace("home", "");
      const lowerKey = key.charAt(0).toLowerCase() + key.slice(1);
      value = parseFloat(String(homeFeatures[lowerKey] || homeFeatures[key] || 0));
    } else if (featureName.startsWith("away")) {
      const key = featureName.replace("away", "");
      const lowerKey = key.charAt(0).toLowerCase() + key.slice(1);
      value = parseFloat(String(awayFeatures[lowerKey] || awayFeatures[key] || 0));
    }
    features.push(isNaN(value) ? 0 : value);
  }
  return features;
}
function normalizeFeature(value, mean, std) {
  if (std === 0)
    return 0;
  return (value - mean) / std;
}
function applyCalibration(rawProb, calibration) {
  if (!calibration)
    return rawProb;
  if (calibration.method === "temperature" && calibration.temperature) {
    const logit = Math.log(rawProb / (1 - rawProb));
    const scaledLogit = logit / calibration.temperature;
    return 1 / (1 + Math.exp(-scaledLogit));
  }
  if (calibration.method === "beta" && calibration.betaParams) {
    const { a, b } = calibration.betaParams;
    return Math.pow(rawProb, a) / (Math.pow(rawProb, a) + Math.pow(1 - rawProb, b));
  }
  return rawProb;
}
function predictRandomForest(features, model) {
  if (!model.modelJSON) {
    throw new Error("Random Forest model JSON not found");
  }
  const { indexes, thresholds, values } = model.modelJSON;
  if (!indexes || !thresholds || !values) {
    throw new Error("Invalid Random Forest model structure");
  }
  let totalProb = 0;
  const numTrees = indexes.length;
  for (let t = 0; t < numTrees; t++) {
    let nodeIdx = 0;
    while (true) {
      const featureIdx = indexes[t][nodeIdx];
      const threshold = thresholds[t][nodeIdx];
      if (featureIdx === -2) {
        const probs = values[t][nodeIdx];
        totalProb += probs[1] / (probs[0] + probs[1]);
        break;
      }
      if (features[featureIdx] <= threshold) {
        nodeIdx = nodeIdx * 2 + 1;
      } else {
        nodeIdx = nodeIdx * 2 + 2;
      }
      if (nodeIdx >= indexes[t].length) {
        break;
      }
    }
  }
  return totalProb / numTrees;
}
function predict(model, homeFeatures, awayFeatures) {
  const features = buildFeatureVector(homeFeatures, awayFeatures, model.featureNames);
  let normalizedFeatures = features;
  if (model.scaler) {
    normalizedFeatures = features.map((value, i) => {
      const featureName = model.featureNames[i];
      const mean = model.scaler.means[featureName] || 0;
      const std = model.scaler.stds[featureName] || 1;
      return normalizeFeature(value, mean, std);
    });
  }
  const classifier = model.classifiers[0];
  let rawProb = 0.5;
  if (classifier.modelJSON) {
    rawProb = predictRandomForest(normalizedFeatures, classifier);
  } else if (classifier.theta) {
    const logit = classifier.theta.reduce((sum, weight, i) => {
      return sum + weight * normalizedFeatures[i];
    }, 0);
    rawProb = 1 / (1 + Math.exp(-logit));
  }
  return applyCalibration(rawProb, model.calibration);
}

// src/index.ts
var BUCKET = process.env.BUCKET || `sportline-data-${process.env.USER || "dev"}`;
var MIN_EDGE = 0.03;
function americanToImpliedProb(americanOdds) {
  if (americanOdds > 0) {
    return 100 / (americanOdds + 100);
  } else {
    return -americanOdds / (-americanOdds + 100);
  }
}
function calculateEV(probability, americanOdds) {
  const impliedProb = americanToImpliedProb(americanOdds);
  const decimalOdds = americanOdds > 0 ? americanOdds / 100 + 1 : 100 / -americanOdds + 1;
  return probability * decimalOdds - 1;
}
function passesJuiceGate(betOdds, betEdge) {
  const MAX_VIG_PRICE = -115;
  const EDGE_REQUIRED_IF_VIGGY = 0.04;
  if (betOdds <= MAX_VIG_PRICE && betEdge < EDGE_REQUIRED_IF_VIGGY)
    return false;
  return true;
}
async function handler(event) {
  console.log("Update Lambda starting...", { event });
  const sports = ["nba", "ncaam", "nhl"];
  const allRecommendations = [];
  for (const sport of sports) {
    try {
      console.log(`Processing ${sport}...`);
      const moneylineModel = await getJsonFromS3(
        BUCKET,
        `models/${sport}/moneyline-2025.json`
      );
      const spreadModel = await getJsonFromS3(
        BUCKET,
        `models/${sport}/spread-2025.json`
      );
      const featuresData = await getJsonFromS3(
        BUCKET,
        `features/${sport}-features.json`
      );
      const gamesData = await getJsonFromS3(BUCKET, `features/${sport}-games.json`);
      console.log(`  Found ${gamesData.games.length} upcoming games`);
      if (gamesData.games.length === 0) {
        continue;
      }
      const gameIds = gamesData.games.map((g) => g.id);
      const oddsMap = await fetchOddsForGames(sport, gameIds);
      console.log(`  Fetched odds for ${oddsMap.size} games`);
      for (const game of gamesData.games) {
        const odds = oddsMap.get(game.id);
        if (!odds) {
          continue;
        }
        const homeFeatures = featuresData.teams[game.homeTeamId];
        const awayFeatures = featuresData.teams[game.awayTeamId];
        if (!homeFeatures || !awayFeatures) {
          console.warn(`  Missing features for game ${game.id}`);
          continue;
        }
        if (odds.priceHome !== null) {
          const homeWinProb = predict(moneylineModel, homeFeatures, awayFeatures);
          const impliedProb = americanToImpliedProb(odds.priceHome);
          const edge = homeWinProb - impliedProb;
          const ev = calculateEV(homeWinProb, odds.priceHome);
          if (edge >= MIN_EDGE && passesJuiceGate(odds.priceHome, edge)) {
            allRecommendations.push({
              gameId: game.id,
              gameDate: game.date,
              sport,
              homeTeamId: game.homeTeamId,
              awayTeamId: game.awayTeamId,
              market: "moneyline",
              side: "home",
              modelProbability: homeWinProb,
              impliedProbability: impliedProb,
              odds: odds.priceHome,
              line: null,
              edge,
              ev,
              provider: odds.provider
            });
          }
        }
        if (odds.priceAway !== null) {
          const homeWinProb = predict(moneylineModel, homeFeatures, awayFeatures);
          const awayWinProb = 1 - homeWinProb;
          const impliedProb = americanToImpliedProb(odds.priceAway);
          const edge = awayWinProb - impliedProb;
          const ev = calculateEV(awayWinProb, odds.priceAway);
          if (edge >= MIN_EDGE && passesJuiceGate(odds.priceAway, edge)) {
            allRecommendations.push({
              gameId: game.id,
              gameDate: game.date,
              sport,
              homeTeamId: game.homeTeamId,
              awayTeamId: game.awayTeamId,
              market: "moneyline",
              side: "away",
              modelProbability: awayWinProb,
              impliedProbability: impliedProb,
              odds: odds.priceAway,
              line: null,
              edge,
              ev,
              provider: odds.provider
            });
          }
        }
        if (odds.line !== null) {
          const homeCoversProb = predict(spreadModel, homeFeatures, awayFeatures);
          const spreadOdds = -110;
          const impliedProb = americanToImpliedProb(spreadOdds);
          const edge = homeCoversProb - impliedProb;
          const ev = calculateEV(homeCoversProb, spreadOdds);
          if (edge >= MIN_EDGE && passesJuiceGate(spreadOdds, edge)) {
            allRecommendations.push({
              gameId: game.id,
              gameDate: game.date,
              sport,
              homeTeamId: game.homeTeamId,
              awayTeamId: game.awayTeamId,
              market: "spread",
              side: homeCoversProb >= 0.5 ? "home" : "away",
              modelProbability: homeCoversProb >= 0.5 ? homeCoversProb : 1 - homeCoversProb,
              impliedProbability: impliedProb,
              odds: spreadOdds,
              line: odds.line,
              edge,
              ev,
              provider: odds.provider
            });
          }
        }
      }
    } catch (error) {
      console.error(`Error processing ${sport}:`, error);
    }
  }
  allRecommendations.sort((a, b) => b.edge - a.edge);
  const output = {
    generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    recommendations: allRecommendations
  };
  await putJsonToS3(BUCKET, "daily/recs.json", output);
  console.log(`Update complete: ${allRecommendations.length} recommendations`);
  return {
    statusCode: 200,
    body: JSON.stringify({
      success: true,
      count: allRecommendations.length,
      generatedAt: output.generatedAt
    })
  };
}
export {
  handler
};
